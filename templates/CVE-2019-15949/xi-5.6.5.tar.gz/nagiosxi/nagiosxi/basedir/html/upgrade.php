<?php
//
// Script that runs after upgrade
// Copyright (c) 2008-2018 Nagios Enterprises, LLC. All rights reserved.
//

// Hide notices on upgrade
error_reporting(E_ALL & ~E_NOTICE);

require_once(dirname(__FILE__) . '/config.inc.php');
require_once(dirname(__FILE__) . '/includes/auth.inc.php');
require_once(dirname(__FILE__) . '/includes/utils.inc.php');
require_once(dirname(__FILE__) . '/includes/pageparts.inc.php');


// Initialization stuff
pre_init();
init_session();
check_prereqs();


// Do the actual upgrade (force upgrade from CLI only)
if (PHP_SAPI == 'cli') {
    do_upgrade();
} else {
    header("Location: index.php");
}


function do_upgrade()
{
    $version = get_install_version();

    ///////////////////////////////////////////////////////
    ////// 2009R1.2 FIXES /////////////////////////////////
    ///////////////////////////////////////////////////////

    // Random PNP / nagios core backend password (used for performance graphs)
    if (get_component_credential("pnp", "username") != "nagiosxi") {
        $nagioscore_backend_password = random_string(6);
        $pnp_username = "nagiosxi";
        set_component_credential("pnp", "username", $pnp_username);
        set_component_credential("pnp", "password", $nagioscore_backend_password);
        $args = array(
            "username" => $pnp_username,
            "password" => $nagioscore_backend_password
        );
        submit_command(COMMAND_NAGIOSXI_SET_HTACCESS, serialize($args));
    }

    ///////////////////////////////////////////////////////
    ////// 2009R1.2D FIXES /////////////////////////////////
    ///////////////////////////////////////////////////////

    // Randomize default nagiosadmin backend ticket
    $uid = get_user_id("nagiosadmin");
    if ($uid > 0) {
        $backend_ticket = get_user_attr($uid, "backend_ticket");
        if ($backend_ticket == "1234") {
            change_user_attr($uid, "backend_ticket", random_string(32));
        }
    }

    // Updates for version 5.5.0
    if (version_compare($version, '5.5.0', '<')) {

        // Set all current phone numbers to verified if entered before
        // version 5.5.0 by default
        $users = get_users();
        foreach ($users as $user) {
            $uid = $user['user_id'];

            // Update mobile phone number
            $mobile_number = get_user_meta($uid, 'mobile_number');
            if (!empty($mobile_number)) {
                set_user_meta($uid, 'phone_verified', 1);
            }
        
            // Update CCM access to login access if they are an advanced user
            if (get_user_meta($uid, "advanced_user", 0)) {
                set_user_meta($uid, 'ccm_access', 1);
            }

            // Update insecure login with md5 password (since new passwords will automatically apply on login)
            $md5 = get_user_attr($uid, "password");
            set_user_meta($uid, "insecure_login_ticket", $md5);

        }

    }
    
    // Set installation flags
    set_db_version();
    set_install_version();

    // Do update check
    do_update_check(true, false, false, true);
}