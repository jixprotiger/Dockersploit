#!/bin/bash
#
# Restores the Default Configuration in the CCM/Nagios Core for Nagios XI
# Copyright (c) 2008-2018 Nagios Enterprises, LLC. All rights reserved.
#

BASEDIR=$(dirname $(readlink -f $0))
VARDIR="$BASEDIR/../var"
NAGIOS_ETC=/usr/local/nagios/etc

DEFAULTS="$BASEDIR/nagiosql_defaults.sql"

HOST="localhost"
USER="root"
PASSWORD="nagiosxi"
DATABASE="nagiosql"

XI_TYPE="mysql"
XI_HOST="localhost"
XI_USER="nagiosxi"
XI_PASSWORD="n@gweb"
XI_DATABASE="nagiosxi"

# Verify user wants to reset everything
fmt -s -w $(tput cols) <<-EOF
========================
Nagios XI Reset Defaults
========================
WARNING: This script will reset all of your configurations to
the defaults set after a clean install of Nagios XI. 
EOF

read -p "Are you sure you want to continue? [y/N] " res

if [ "$res" = "y" -o "$res" = "Y" ]; then
    echo "Proceeding with reset..."
else
    echo "Script cancelled"
    exit 1
fi

# Gather information to check for offloaded dbs
if [ -f $BASEDIR/../html/config.inc.php ]; then

    # Import Nagios XI and xi-sys.cfg config vars
    . $BASEDIR/../var/xi-sys.cfg
    eval $(php $BASEDIR/import_xiconfig.php)

    # Get the nagiosql info
    eval "CFG_HOST=\$cfg__db_info__nagiosql__dbserver"
    eval "CFG_USER=\$cfg__db_info__nagiosql__user"
    eval "CFG_PASSWORD=\$cfg__db_info__nagiosql__pwd"
    eval "CFG_DATABASE=\$cfg__db_info__nagiosql__db"

    # Overwrite if found
    if [ "x$CFG_HOST" != "x" ]; then
        HOST=$CFG_HOST
    fi
    if [ "x$CFG_USER" != "x" ]; then
        USER=$CFG_USER
    fi
    if [ "x$CFG_PASSWORD" != "x" ]; then
        PASSWORD=$CFG_PASSWORD
    fi
    if [ "x$CFG_DATABASE" != "x" ]; then
        DATABASE=$CFG_DATABASE
    fi

    # Get the nagiosxi db info so we can randomize our nagiosql password
    eval "CFG_XI_TYPE=\$cfg__db_info__nagiosxi__dbtype"
    eval "CFG_XI_HOST=\$cfg__db_info__nagiosxi__dbserver"
    eval "CFG_XI_USER=\$cfg__db_info__nagiosxi__user"
    eval "CFG_XI_PASSWORD=\$cfg__db_info__nagiosxi__pwd"
    eval "CFG_XI_DATABASE=\$cfg__db_info__nagiosxi__db"

    # Overwrite if found
    if [ "x$CFG_XI_TYPE" != "x" ]; then
        XI_TYPE=$CFG_XI_TYPE
    fi
    if [ "x$CFG_XI_HOST" != "x" ]; then
        XI_HOST=$CFG_XI_HOST
    fi
    if [ "x$CFG_XI_USER" != "x" ]; then
        XI_USER=$CFG_XI_USER
    fi
    if [ "x$CFG_XI_PASSWORD" != "x" ]; then
        XI_PASSWORD=$CFG_XI_PASSWORD
    fi
    if [ "x$CFG_XI_DATABASE" != "x" ]; then
        XI_DATABASE=$CFG_XI_DATABASE
    fi

fi

# Backup the existing configuration
mysqldump -h "$HOST" -u "$USER" -p"$PASSWORD" "$DATABASE" > $VARDIR/nagiosql_backup."$(date +%s)".sql

# Restore the defaults
mysql -h "$HOST" -u "$USER" -p"$PASSWORD" "$DATABASE" < "$DEFAULTS"

# Generate a new password for nagiosql user
NEW_PW=$(cat /dev/urandom | tr -dc "A-Za-z0-9" | head -c 16)

# Update nagiosql db
mysql -h "$HOST" -u "$USER" -p"$PASSWORD" "$DATABASE" -e "UPDATE tbl_user SET  password = md5('$NEW_PW') WHERE username = 'nagiosxi';"

# Update the xi_options table
XI_UPDATE="UPDATE xi_options SET value = '$NEW_PW' WHERE name = 'nagiosql_password';"
if [ "$XI_TYPE" == "mysql" ]; then
    mysql -h "$XI_HOST" -u "$XI_USER" -p"$XI_PASSWORD" "$XI_DATABASE" -e "$XI_UPDATE"
else
    echo "$XI_UPDATE" | psql "$XI_DATABASE" "$XI_USER"
fi

# Remove existing configuration files
rm -f $NAGIOS_ETC/commands.cfg
rm -f $NAGIOS_ETC/contactgroups.cfg
rm -f $NAGIOS_ETC/contacts.cfg
rm -f $NAGIOS_ETC/contacttemplates.cfg
rm -f $NAGIOS_ETC/hostdependencies.cfg
rm -f $NAGIOS_ETC/hostescalations.cfg
rm -f $NAGIOS_ETC/hostextinfo.cfg
rm -f $NAGIOS_ETC/hostgroups.cfg
rm -f $NAGIOS_ETC/hosts/*
rm -f $NAGIOS_ETC/hosttemplates.cfg
rm -f $NAGIOS_ETC/servicedependencies.cfg
rm -f $NAGIOS_ETC/serviceescalations.cfg
rm -f $NAGIOS_ETC/serviceextinfo.cfg
rm -f $NAGIOS_ETC/servicegroups.cfg
rm -f $NAGIOS_ETC/services/*
rm -f $NAGIOS_ETC/servicetemplates.cfg
rm -f $NAGIOS_ETC/timeperiods.cfg

# Regenerate configs and restart nagios
$BASEDIR/reconfigure_nagios.sh

sleep 5
echo ""
echo ""
